const Passenger = require('./models/Passenger');

exports.registerPassenger = async (req, res) => {
  try {
    const newPassenger = new Passenger(req.body);
    await newPassenger.save();
    res.status(201).json({ message: 'Passenger registered successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
