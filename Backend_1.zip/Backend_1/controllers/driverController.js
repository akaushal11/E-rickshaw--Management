const Driver = require('./models/Driver');

exports.registerDriver = async (req, res) => {
  try {
    const newDriver = new Driver(req.body);
    await newDriver.save();
    res.status(201).json({ message: 'Driver registered successfully' });
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
};
