const mongoose = require('mongoose');

const tripSchema = new mongoose.Schema({
  passengerId: { type: mongoose.Schema.Types.ObjectId, ref: 'Passenger' },
  driverId: { type: mongoose.Schema.Types.ObjectId, ref: 'Driver' },
  pickupLocation: String,
  dropoffLocation: String,
  status: { type: String, default: 'pending' }
});

module.exports = mongoose.model('Trip', tripSchema);
